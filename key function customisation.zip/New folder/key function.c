#include <stdio.h>
#include <stdlib.h>

const char* HWDB_PATH = "/etc/udev/hwdb.d/90-custom-keyboard.hwdb";

void keycode_to_hex(int keycode, char* hex) {
    sprintf(hex, "%x", keycode);
}

void apply_remap(int keycode, const char* symbol) {
    char hex[10];
    keycode_to_hex(keycode, hex);

    FILE* file = fopen("/tmp/temp_hwdb.txt", "w");
    if (!file) {
        printf("Error creating file.\n");
        exit(1);
    }

    fprintf(file, "evdev:input:b*\n KEYBOARD_KEY_%s=%s\n", hex, symbol);
    fclose(file);

    char command[256];

    sprintf(command, "sudo mv /tmp/temp_hwdb.txt %s", HWDB_PATH);
    system(command);

    system("sudo udevadm hwdb --update");
    system("sudo udevadm trigger");

    printf("Remap applied: keycode %d → %s\n", keycode, symbol);
    printf("Please reboot your system to take effect.\n");
}

void revert_remap() {
    char command[256];

    sprintf(command, "sudo rm -f %s", HWDB_PATH);
    system(command);

    system("sudo udevadm hwdb --update");
    system("sudo udevadm trigger");

    printf("Remap reverted. Please reboot.\n");
}

int main() {
    int choice;
    printf("1. Apply remap\n");
    printf("2. Revert remap\n");
    printf("Enter choice: ");
    scanf("%d", &choice);
    if (choice == 1) {
        int keycode;
        char symbol[50];
        printf("Enter keycode: ");
        scanf("%d", &keycode);
        printf("Enter symbol (e.g., less for <): ");
        scanf("%s", symbol);
        apply_remap(keycode, symbol);
    } else if (choice == 2) {
        revert_remap();
    } else {
        printf("Invalid choice.\n");
    }

    return 0;
}